--
-- PostgreSQL database dump
--

\restrict 980ZZpxLgukSC5mvWeZcLHjuHEiWYLkiUFR0viL6EVlWfFjZsdPdPmMIGaGTfqk

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: tangleweave
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO tangleweave;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    admin_id character varying(255) NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50),
    target_id character varying(255),
    details jsonb,
    ip_address inet,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.admin_audit_log OWNER TO tangleweave;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    key_hash character varying(255) NOT NULL,
    permissions text[] DEFAULT '{}'::text[],
    is_active boolean DEFAULT true,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.api_keys OWNER TO tangleweave;

--
-- Name: payment_webhooks; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.payment_webhooks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    provider character varying(50) NOT NULL,
    event_type character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    processed boolean DEFAULT false,
    processed_at timestamp with time zone,
    error_message text,
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payment_webhooks OWNER TO tangleweave;

--
-- Name: promocodes; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.promocodes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    code character varying(100) NOT NULL,
    reward_type character varying(50) NOT NULL,
    amount integer NOT NULL,
    max_uses integer,
    used_count integer DEFAULT 0,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.promocodes OWNER TO tangleweave;

--
-- Name: reward_history; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.reward_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    source character varying(255) NOT NULL,
    reward_type character varying(50),
    amount integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reward_history OWNER TO tangleweave;

--
-- Name: rewards; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.rewards (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    reward_type character varying(50) NOT NULL,
    amount integer NOT NULL,
    reason text,
    granted_by character varying(255),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rewards OWNER TO tangleweave;

--
-- Name: users; Type: TABLE; Schema: public; Owner: tangleweave
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    external_id character varying(255) NOT NULL,
    email character varying(255),
    display_name character varying(255),
    role character varying(50) DEFAULT 'player'::character varying,
    balance integer DEFAULT 0,
    is_banned boolean DEFAULT false,
    ban_reason text,
    ban_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO tangleweave;

--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.admin_audit_log (id, admin_id, action, target_type, target_id, details, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.api_keys (id, name, key_hash, permissions, is_active, last_used_at, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: payment_webhooks; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.payment_webhooks (id, provider, event_type, payload, processed, processed_at, error_message, retry_count, created_at) FROM stdin;
\.


--
-- Data for Name: promocodes; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.promocodes (id, code, reward_type, amount, max_uses, used_count, expires_at, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: reward_history; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.reward_history (id, user_id, source, reward_type, amount, created_at) FROM stdin;
\.


--
-- Data for Name: rewards; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.rewards (id, user_id, reward_type, amount, reason, granted_by, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tangleweave
--

COPY public.users (id, external_id, email, display_name, role, balance, is_banned, ban_reason, ban_expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: payment_webhooks payment_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.payment_webhooks
    ADD CONSTRAINT payment_webhooks_pkey PRIMARY KEY (id);


--
-- Name: promocodes promocodes_code_key; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_code_key UNIQUE (code);


--
-- Name: promocodes promocodes_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.promocodes
    ADD CONSTRAINT promocodes_pkey PRIMARY KEY (id);


--
-- Name: reward_history reward_history_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.reward_history
    ADD CONSTRAINT reward_history_pkey PRIMARY KEY (id);


--
-- Name: rewards rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.rewards
    ADD CONSTRAINT rewards_pkey PRIMARY KEY (id);


--
-- Name: users users_external_id_key; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_external_id_key UNIQUE (external_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_log_admin; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_audit_log_admin ON public.admin_audit_log USING btree (admin_id, created_at DESC);


--
-- Name: idx_audit_log_target; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_audit_log_target ON public.admin_audit_log USING btree (target_type, target_id);


--
-- Name: idx_payment_webhooks_processed; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_payment_webhooks_processed ON public.payment_webhooks USING btree (processed, created_at) WHERE (processed = false);


--
-- Name: idx_payment_webhooks_provider; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_payment_webhooks_provider ON public.payment_webhooks USING btree (provider, event_type);


--
-- Name: idx_promocodes_active; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_promocodes_active ON public.promocodes USING btree (is_active, expires_at) WHERE (is_active = true);


--
-- Name: idx_promocodes_code; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_promocodes_code ON public.promocodes USING btree (code);


--
-- Name: idx_rewards_created_at; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_rewards_created_at ON public.rewards USING btree (created_at);


--
-- Name: idx_rewards_type; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_rewards_type ON public.rewards USING btree (reward_type);


--
-- Name: idx_rewards_user_id; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_rewards_user_id ON public.rewards USING btree (user_id);


--
-- Name: idx_users_banned; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_users_banned ON public.users USING btree (is_banned) WHERE (is_banned = true);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_external_id; Type: INDEX; Schema: public; Owner: tangleweave
--

CREATE INDEX idx_users_external_id ON public.users USING btree (external_id);


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: tangleweave
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: reward_history reward_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.reward_history
    ADD CONSTRAINT reward_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rewards rewards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: tangleweave
--

ALTER TABLE ONLY public.rewards
    ADD CONSTRAINT rewards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 980ZZpxLgukSC5mvWeZcLHjuHEiWYLkiUFR0viL6EVlWfFjZsdPdPmMIGaGTfqk

